INSERT INTO users (username,contactNo,userType,passwordHash,email,profilePicture) VALUES ('LakkanaDolapihilla','0776712741','Admin','5E884898DA28047151D0E56F8DC6292773603D0D6AABBDD62A11EF721D1542D8','lakkanad@gmail.com','a');
INSERT INTO users (username,contactNo,userType,passwordHash,email,profilePicture) VALUES ('BanukaSandeepa','0775996008','Buyer','5E884898DA28047151D0E56F8DC6292773603D0D6AABBDD62A11EF721D1542D8','busdbubg','b');
INSERT INTO users (username,contactNo,userType,passwordHash,email,profilePicture) VALUES ('DhanushkaDolapihilla','0777812418','Seller','5E884898DA28047151D0E56F8DC6292773603D0D6AABBDD62A11EF721D1542D8','gfuiygyug','c');

INSERT INTO products (creator,productName,productImage,productDescription,productPrice,productCount) VALUES ('DhanushkaDolapihilla','watch','a','yfvyvuf',500.00,5);
INSERT INTO products (creator,productName,productImage,productDescription,productPrice,productCount) VALUES ('DhanushkaDolapihilla','laptop','b','kycuiwyu',100000.00,2);
INSERT INTO products (creator,productName,productImage,productDescription,productPrice,productCount) VALUES ('DhanushkaDolapihilla','phone','c','vtfuwt',50000.50,7);

INSERT INTO addresses (username, address) VALUES ('LakkanaDolapihilla' , '82/2,Katugastota');
INSERT INTO addresses (username, address) VALUES ('BanukaSandeepa' , 'Sample Address');
INSERT INTO addresses (username, address) VALUES ('DhanushkaDolapihilla' , '23/2/1/1, Mirihana');