package com.paf.n3ag6.models;

public class Supplier {
	
	private int supplierId;
	private String Suppliername;
	private String companyname;
	private String productitem;
	private String address;
	private String contact;
	private String email;
	public int getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}
	public String getSuppliername() {
		return Suppliername;
	}
	public void setSuppliername(String suppliername) {
		Suppliername = suppliername;
	}
	public String getCompanyname() {
		return companyname;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	public String getProductitem() {
		return productitem;
	}
	public void setProductitem(String productitem) {
		this.productitem = productitem;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	

}
